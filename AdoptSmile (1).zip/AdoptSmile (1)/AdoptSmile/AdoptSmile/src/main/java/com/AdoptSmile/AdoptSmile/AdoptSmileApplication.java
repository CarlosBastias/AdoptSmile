package com.AdoptSmile.AdoptSmile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdoptSmileApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdoptSmileApplication.class, args);
	}

}
