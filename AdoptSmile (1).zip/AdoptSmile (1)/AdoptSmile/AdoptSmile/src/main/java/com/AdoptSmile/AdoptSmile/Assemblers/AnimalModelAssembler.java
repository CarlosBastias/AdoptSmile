package com.AdoptSmile.AdoptSmile.Assemblers;

import com.AdoptSmile.AdoptSmile.Controller.v2.AnimalControllerV2;
import com.AdoptSmile.AdoptSmile.Model.Animal;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Component
public class AnimalModelAssembler implements RepresentationModelAssembler<Animal, EntityModel<Animal>> {

    @Override
    public EntityModel<Animal> toModel(Animal animal) {
        return EntityModel.of(animal,
                linkTo(methodOn(AnimalControllerV2.class).getById(animal.getId_animal().longValue())).withSelfRel(),
                linkTo(methodOn(AnimalControllerV2.class).getAll()).withRel("animales"),
                linkTo(methodOn(AnimalControllerV2.class).update(animal.getId_animal().longValue(), animal)).withRel("actualizar"),
                linkTo(methodOn(AnimalControllerV2.class).patch(animal.getId_animal().longValue(), animal)).withRel("actualizar-parcial"),
                linkTo(methodOn(AnimalControllerV2.class).deleteAnimal(animal.getId_animal().longValue())).withRel("eliminar")
        );
    }
}
