package com.AdoptSmile.AdoptSmile.Assemblers;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

import com.AdoptSmile.AdoptSmile.Model.Comuna;
import com.AdoptSmile.AdoptSmile.Controller.v2.ComunaControllerV2;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Component
public class ComunaModelAssembler implements RepresentationModelAssembler<Comuna, EntityModel<Comuna>> {
    @Override
    public EntityModel<Comuna> toModel(Comuna comuna) {
        return EntityModel.of(comuna,
            linkTo(methodOn(ComunaControllerV2.class).getById(comuna.getId_comuna().longValue())).withSelfRel(),
            linkTo(methodOn(ComunaControllerV2.class).getAll()).withRel("comunas"),
            linkTo(methodOn(ComunaControllerV2.class).update(comuna.getId_comuna().longValue(), comuna)).withRel("actualizar"),
            linkTo(methodOn(ComunaControllerV2.class).patch(comuna.getId_comuna().longValue(), comuna)).withRel("actualizar-parcial"),
            linkTo(methodOn(ComunaControllerV2.class).delete(comuna.getId_comuna().longValue())).withRel("eliminar")
        );
    }
}

