package com.AdoptSmile.AdoptSmile.Assemblers;

import com.AdoptSmile.AdoptSmile.Controller.v2.EspecieControllerV2;
import com.AdoptSmile.AdoptSmile.Model.Especie;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Component
public class EspecieModelAssembler implements RepresentationModelAssembler<Especie, EntityModel<Especie>> {

    @Override
    public EntityModel<Especie> toModel(Especie especie) {

        return EntityModel.of(especie,
                linkTo(methodOn(EspecieControllerV2.class).getById(especie.getId_especie().longValue())).withSelfRel(),
                linkTo(methodOn(EspecieControllerV2.class).getAll()).withRel("especies"),
                linkTo(methodOn(EspecieControllerV2.class).update(especie.getId_especie().longValue(), especie)).withRel("actualizar"),
                linkTo(methodOn(EspecieControllerV2.class).patch(especie.getId_especie().longValue(), especie)).withRel("actualizar-parcial"),
                linkTo(methodOn(EspecieControllerV2.class).delete(especie.getId_especie().longValue())).withRel("eliminar")
        );
    }
}
