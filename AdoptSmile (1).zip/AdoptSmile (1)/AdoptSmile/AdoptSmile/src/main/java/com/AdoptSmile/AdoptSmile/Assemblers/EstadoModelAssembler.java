package com.AdoptSmile.AdoptSmile.Assemblers;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

import com.AdoptSmile.AdoptSmile.Controller.v2.EstadoControllerV2;
import com.AdoptSmile.AdoptSmile.Model.Estado;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;


@Component
public class EstadoModelAssembler implements RepresentationModelAssembler<Estado, EntityModel<Estado>> {

    @Override
    public EntityModel<Estado> toModel(Estado estado) {

        return EntityModel.of(estado,
                linkTo(methodOn(EstadoControllerV2.class).getById(estado.getId_estado().longValue())).withSelfRel(),
                linkTo(methodOn(EstadoControllerV2.class).getAll()).withRel("estados"),
                linkTo(methodOn(EstadoControllerV2.class).update(estado.getId_estado().longValue(), estado)).withRel("actualizar"),
                linkTo(methodOn(EstadoControllerV2.class).patch(estado.getId_estado().longValue(), estado)).withRel("actualizar-parcial"),
                linkTo(methodOn(EstadoControllerV2.class).delete(estado.getId_estado().longValue())).withRel("eliminar")
        );
    }
}