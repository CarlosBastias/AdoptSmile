package com.AdoptSmile.AdoptSmile.Assemblers;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

import com.AdoptSmile.AdoptSmile.Controller.v2.RazaControllerV2;
import com.AdoptSmile.AdoptSmile.Model.Raza;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Component
public class RazaModelAssembler implements RepresentationModelAssembler<Raza, EntityModel<Raza>> {

    @Override
    public EntityModel<Raza> toModel(Raza raza) {
        return EntityModel.of(raza,
            linkTo(methodOn(RazaControllerV2.class).getById(raza.getId_raza().longValue())).withSelfRel(),
            linkTo(methodOn(RazaControllerV2.class).getAll()).withRel("razas"),
            linkTo(methodOn(RazaControllerV2.class).update(raza.getId_raza().longValue(), raza)).withRel("actualizar"),
            linkTo(methodOn(RazaControllerV2.class).patch(raza.getId_raza().longValue(), raza)).withRel("actualizar-parcial"),
            linkTo(methodOn(RazaControllerV2.class).delete(raza.getId_raza().longValue())).withRel("eliminar")
        );
    }
}
