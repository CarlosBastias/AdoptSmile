package com.AdoptSmile.AdoptSmile.Assemblers;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

import com.AdoptSmile.AdoptSmile.Controller.v2.RegionControllerV2;
import com.AdoptSmile.AdoptSmile.Model.Region;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Component
public class RegionModelAssembler implements RepresentationModelAssembler<Region, EntityModel<Region>> {

    @Override
    public EntityModel<Region> toModel(Region region) {

        return EntityModel.of(region,
            linkTo(methodOn(RegionControllerV2.class).getById(region.getId_region().longValue())).withSelfRel(),
            linkTo(methodOn(RegionControllerV2.class).getAll()).withRel("regiones"),
            linkTo(methodOn(RegionControllerV2.class).update(region.getId_region().longValue(), region)).withRel("actualizar"),
            linkTo(methodOn(RegionControllerV2.class).patch(region.getId_region().longValue(), region)).withRel("actualizar-parcial"),
            linkTo(methodOn(RegionControllerV2.class).delete(region.getId_region().longValue())).withRel("eliminar")
        );
    }
}
