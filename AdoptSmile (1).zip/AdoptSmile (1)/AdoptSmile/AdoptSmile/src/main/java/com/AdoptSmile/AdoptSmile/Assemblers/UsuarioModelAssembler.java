package com.AdoptSmile.AdoptSmile.Assemblers;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

import com.AdoptSmile.AdoptSmile.Controller.v2.UsuarioControllerV2;
import com.AdoptSmile.AdoptSmile.Model.Usuario;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@Component
public class UsuarioModelAssembler implements RepresentationModelAssembler<Usuario, EntityModel<Usuario>> {

    @Override
    public EntityModel<Usuario> toModel(Usuario usuario) {

        return EntityModel.of(
            usuario,
            linkTo(methodOn(UsuarioControllerV2.class).getById(usuario.getId_usuario().longValue())).withSelfRel(),
            linkTo(methodOn(UsuarioControllerV2.class).getAll()).withRel("usuarios"),
            linkTo(methodOn(UsuarioControllerV2.class).update(usuario.getId_usuario().longValue(), usuario)).withRel("actualizar"),
            linkTo(methodOn(UsuarioControllerV2.class).patch(usuario.getId_usuario().longValue(), usuario)).withRel("actualizar-parcial"),
            linkTo(methodOn(UsuarioControllerV2.class).delete(usuario.getId_usuario().longValue())).withRel("eliminar")
        );
    }
}
