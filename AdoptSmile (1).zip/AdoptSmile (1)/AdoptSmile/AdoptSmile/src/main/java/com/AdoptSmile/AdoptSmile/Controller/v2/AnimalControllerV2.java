package com.AdoptSmile.AdoptSmile.Controller.v2;

import com.AdoptSmile.AdoptSmile.Assemblers.AnimalModelAssembler;
import com.AdoptSmile.AdoptSmile.Model.Animal;
import com.AdoptSmile.AdoptSmile.Service.AnimalService;

import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v2/animales")
@Tag(name = "Animales", description = "Operaciones relacionadas con los animales en adopción")
public class AnimalControllerV2 {

    @Autowired
    private AnimalService animalService;

    @Autowired
    private AnimalModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<CollectionModel<EntityModel<Animal>>> getAll() {
        List<EntityModel<Animal>> animales = animalService.findAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        if (animales.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(CollectionModel.of(
                animales,
                linkTo(methodOn(AnimalControllerV2.class).getAll()).withSelfRel()
        ));
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Animal>> getById(@PathVariable Long id) {
        Animal obj = animalService.findById(id);
        return obj == null
                ? ResponseEntity.notFound().build()
                : ResponseEntity.ok(assembler.toModel(obj));
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Animal>> create(@RequestBody Animal obj) {
        Animal saved = animalService.save(obj);
        return ResponseEntity
                .created(linkTo(methodOn(AnimalControllerV2.class).getById(saved.getId_animal().longValue())).toUri())
                .body(assembler.toModel(saved));
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Animal>> update(@PathVariable Long id, @RequestBody Animal obj) {
        obj.setId_animal(id.intValue());
        Animal updated = animalService.save(obj);
        return ResponseEntity.ok(assembler.toModel(updated));
    }

    @PatchMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Animal>> patch(@PathVariable Long id, @RequestBody Animal cambios) {
        Animal existing = animalService.patchAnimal(id, cambios);
        if (existing == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(existing));
    }

    @DeleteMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<Void> deleteAnimal(@PathVariable Long id) {
        Animal existing = animalService.findById(id);
        if (existing == null) {
            return ResponseEntity.notFound().build();
        }
        animalService.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
