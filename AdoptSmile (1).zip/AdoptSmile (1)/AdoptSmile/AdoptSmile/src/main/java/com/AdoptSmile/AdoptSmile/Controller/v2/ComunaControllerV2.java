package com.AdoptSmile.AdoptSmile.Controller.v2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.AdoptSmile.AdoptSmile.Assemblers.ComunaModelAssembler;
import com.AdoptSmile.AdoptSmile.Model.Comuna;
import com.AdoptSmile.AdoptSmile.Service.ComunaService;

import io.swagger.v3.oas.annotations.tags.Tag;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v2/comunas")
@Tag(name = "Comunas", description = "Operaciones relacionadas con las comunas")
public class ComunaControllerV2 {

    @Autowired
    private ComunaService comunaService;

    @Autowired
    private ComunaModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<CollectionModel<EntityModel<Comuna>>> getAll() {
        List<EntityModel<Comuna>> items = comunaService.findAll().stream()
            .map(assembler::toModel)
            .collect(Collectors.toList());
        if (items.isEmpty()) return ResponseEntity.noContent().build();

        return ResponseEntity.ok(CollectionModel.of(items,
            linkTo(methodOn(ComunaControllerV2.class).getAll()).withSelfRel()));
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Comuna>> getById(@PathVariable Long id) {
        Comuna obj = comunaService.findById(id);
        return obj == null
            ? ResponseEntity.notFound().build()
            : ResponseEntity.ok(assembler.toModel(obj));
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Comuna>> create(@RequestBody Comuna obj) {
        Comuna saved = comunaService.save(obj);
        return ResponseEntity
            .created(linkTo(methodOn(ComunaControllerV2.class).getById(saved.getId_comuna().longValue())).toUri())
            .body(assembler.toModel(saved));
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Comuna>> update(@PathVariable Long id, @RequestBody Comuna obj) {
        obj.setId_comuna(id.intValue());
        Comuna updated = comunaService.save(obj);
        return ResponseEntity.ok(assembler.toModel(updated));
    }

    @PatchMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Comuna>> patch(@PathVariable Long id, @RequestBody Comuna cambios) {
        Comuna updated = comunaService.patchComuna(id.longValue(), cambios);
        return updated == null
            ? ResponseEntity.notFound().build()
            : ResponseEntity.ok(assembler.toModel(updated));
    }

    @DeleteMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        Comuna existing = comunaService.findById(id);
        if (existing == null) return ResponseEntity.notFound().build();
        comunaService.deleteById(id.longValue());
        return ResponseEntity.noContent().build();
    }
}