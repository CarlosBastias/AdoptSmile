package com.AdoptSmile.AdoptSmile.Controller.v2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.AdoptSmile.AdoptSmile.Assemblers.RazaModelAssembler;
import com.AdoptSmile.AdoptSmile.Model.Raza;
import com.AdoptSmile.AdoptSmile.Service.RazaService;
import com.AdoptSmile.AdoptSmile.Repository.RazaRepository;

import io.swagger.v3.oas.annotations.tags.Tag;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v2/razas")
@Tag(name = "Razas", description = "Operaciones relacionadas con las razas de mascotas")
public class RazaControllerV2 {

    @Autowired
    private RazaService razaService;

    @Autowired
    private RazaRepository razaRepository;

    @Autowired
    private RazaModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<CollectionModel<EntityModel<Raza>>> getAll() {
        List<EntityModel<Raza>> items = razaService.findAll().stream()
            .map(assembler::toModel)
            .collect(Collectors.toList());
        if (items.isEmpty()) return ResponseEntity.noContent().build();

        return ResponseEntity.ok(CollectionModel.of(items,
            linkTo(methodOn(RazaControllerV2.class).getAll()).withSelfRel()));
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Raza>> getById(@PathVariable Long id) {
        Raza obj = razaService.findById(id);
        return obj == null
            ? ResponseEntity.notFound().build()
            : ResponseEntity.ok(assembler.toModel(obj));
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Raza>> create(@RequestBody Raza obj) {
        Raza saved = razaService.save(obj);
        return ResponseEntity
            .created(linkTo(methodOn(RazaControllerV2.class).getById(saved.getId_raza().longValue())).toUri())
            .body(assembler.toModel(saved));
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Raza>> update(@PathVariable Long id, @RequestBody Raza obj) {
        obj.setId_raza(id.intValue());
        Raza updated = razaService.save(obj);
        return ResponseEntity.ok(assembler.toModel(updated));
    }

    @PatchMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Raza>> patch(@PathVariable Long id, @RequestBody Raza cambios) {
        Raza updated = razaService.patchRaza(id.longValue(), cambios);
        return updated == null
            ? ResponseEntity.notFound().build()
            : ResponseEntity.ok(assembler.toModel(updated));
    }

    @DeleteMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        Raza existing = razaService.findById(id);
        if (existing == null) return ResponseEntity.notFound().build();
        razaService.deleteById(id.longValue());
        return ResponseEntity.noContent().build();
    }

      // Obtener raza por tipo exacto
    @GetMapping("/tipo/{tipo}")
    public Raza getByTipo(@PathVariable String tipo) {
        return razaRepository.findByTipo(tipo);
    }

    // Obtener razas por especie y región
    @GetMapping("/por-especie-region")
    public List<Raza> getByEspecieRegion(@RequestParam String especie,
                                         @RequestParam String region) {
        return razaRepository.findByEspecieRegion(especie, region);
    }

    // Contar animales por raza y estado
    @GetMapping("/contar-animales")
    public long countByRazaEstado(@RequestParam String raza,
                                  @RequestParam String estado) {
        return razaRepository.countAnimalesPorRazaEstado(raza, estado);
    }

    // Obtener top razas por región y estado
    @GetMapping("/top")
    public List<Object[]> getTopRazasPorRegionEstado(@RequestParam String region,
                                                     @RequestParam String estado) {
        return razaRepository.topRazasPorRegionEstado(region, estado);
    }

    // Obtener edad promedio por raza y región
    @GetMapping("/edad-promedio")
    public Double getAvgEdadPorRazaRegion(@RequestParam String raza,
                                          @RequestParam String region) {
        return razaRepository.avgEdadPorRazaRegion(raza, region);
    }
}