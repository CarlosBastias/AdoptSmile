package com.AdoptSmile.AdoptSmile;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import com.AdoptSmile.AdoptSmile.Model.Animal;
import com.AdoptSmile.AdoptSmile.Model.Animales;
import com.AdoptSmile.AdoptSmile.Model.Comuna;
import com.AdoptSmile.AdoptSmile.Model.Especie;
import com.AdoptSmile.AdoptSmile.Model.Estado;
import com.AdoptSmile.AdoptSmile.Model.Raza;
import com.AdoptSmile.AdoptSmile.Model.Region;
import com.AdoptSmile.AdoptSmile.Model.Usuario;
import com.AdoptSmile.AdoptSmile.Repository.AnimalRepository;
import com.AdoptSmile.AdoptSmile.Repository.AnimalesRepository;
import com.AdoptSmile.AdoptSmile.Repository.ComunaRepository;
import com.AdoptSmile.AdoptSmile.Repository.EspecieRepository;
import com.AdoptSmile.AdoptSmile.Repository.EstadoRepository;
import com.AdoptSmile.AdoptSmile.Repository.RazaRepository;
import com.AdoptSmile.AdoptSmile.Repository.RegionRepository;
import com.AdoptSmile.AdoptSmile.Repository.UsuarioRepository;

import net.datafaker.Faker;

@Profile("dev")
@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private RegionRepository regionRepository;

    @Autowired
    private ComunaRepository comunaRepository;

    @Autowired
    private EspecieRepository especieRepository;

    @Autowired
    private RazaRepository razaRepository;

    @Autowired
    private EstadoRepository estadoRepository;

    @Autowired
    private AnimalRepository animalRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private AnimalesRepository animalesRepository;

    @Override
    public void run(String... args) throws Exception {
        
        Faker faker = new Faker();
        Random random = new Random();

        for (int i = 0; i < 3; i++) {
            Region region = new Region();
            region.setNombre(faker.country().name());
            regionRepository.save(region);
        }

        List<Region> regiones = regionRepository.findAll();

        for (int i = 0; i < 5; i++) {
            Comuna comuna = new Comuna();
            comuna.setNombre(faker.address().city());
            comuna.setRegion(regiones.get(random.nextInt(regiones.size())));
            comunaRepository.save(comuna);
        }

        List<Comuna> comunas = comunaRepository.findAll();

        for (int i = 0; i < 3; i++) {
            Especie especie = new Especie();
            especie.setNombre(faker.animal().name());
            especieRepository.save(especie);
        }

        List<Especie> especies = especieRepository.findAll();

        for (int i = 0; i < 5; i++) {
            Raza raza = new Raza();
            raza.setTipo(faker.dog().breed());
            raza.setEspecie(especies.get(random.nextInt(especies.size())));
            razaRepository.save(raza);
        }

        List<Raza> razas = razaRepository.findAll();

        for (int i = 0; i < 3; i++) {
            Estado estado = new Estado();
            estado.setDescripcion(faker.options().option("Adoptado", "Disponible", "En tratamiento"));
            estadoRepository.save(estado);
        }

        List<Estado> estados = estadoRepository.findAll();

        for (int i = 0; i < 10; i++) {
            Usuario usuario = new Usuario();
            usuario.setNombre(faker.name().fullName());
            usuario.setCorreo(faker.internet().emailAddress());
            usuario.setContrasena("password123");
            usuario.setTelefono(faker.phoneNumber().cellPhone());
            usuario.setDireccion(faker.address().fullAddress());
            usuarioRepository.save(usuario);
        }

        List<Usuario> usuarios = usuarioRepository.findAll();

        for (int i = 0; i < 20; i++) {
            Animal animal = new Animal();
            animal.setEdad(faker.number().numberBetween(1, 15));
            animal.setTamaño(faker.options().option("Pequeño", "Mediano", "Grande"));
            animal.setEspecificaciones(faker.lorem().sentence());
            animal.setNecesidades(faker.lorem().word());
            animal.setEstado(estados.get(random.nextInt(estados.size())));
            animal.setComuna(comunas.get(random.nextInt(comunas.size())));
            animal.setRaza(razas.get(random.nextInt(razas.size())));
            animalRepository.save(animal);
        }

        List<Animal> animales = animalRepository.findAll();

        for (int i = 0; i < 10; i++) {
            Animales adoptado = new Animales();
            adoptado.setUsuario(usuarios.get(random.nextInt(usuarios.size())));
            adoptado.setAnimal(animales.get(random.nextInt(animales.size())));
            animalesRepository.save(adoptado);
        }
    }
}
