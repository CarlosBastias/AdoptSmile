package com.AdoptSmile.AdoptSmile.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.AdoptSmile.AdoptSmile.Model.Animal;
import org.springframework.stereotype.Repository;

@Repository
public interface AnimalRepository extends JpaRepository<Animal, Long> {

    @Query("""
        SELECT a
        FROM Animal a
             JOIN a.comuna c
             JOIN c.region r
             JOIN a.raza ra
             JOIN ra.especie e
             JOIN a.estado est
        WHERE r.nombre = :region
          AND e.nombre = :especie
          AND est.descripcion = :estado
    """)
    List<Animal> findByRegionEspecieEstado(@Param("region") String region,
                                           @Param("especie") String especie,
                                           @Param("estado") String estado);

   
    @Query("""
        SELECT COUNT(a)
        FROM Animal a
             JOIN a.comuna c
             JOIN c.region r
             JOIN a.raza ra
             JOIN ra.especie e
        WHERE e.nombre = :especie
          AND r.id_region = :regionId
          AND a.edad BETWEEN :minEdad AND :maxEdad
    """)
    long countByEspecieRegionEdad(@Param("especie")  String  especie,
                                  @Param("regionId") Integer regionId,
                                  @Param("minEdad")  Integer minEdad,
                                  @Param("maxEdad")  Integer maxEdad);

    
    @Query("""
        SELECT a
        FROM Animal a
             JOIN a.raza ra
             JOIN a.estado est
             JOIN a.comuna c
             JOIN c.region r
        WHERE ra.tipo       = :raza
          AND r.nombre      = :region
          AND est.descripcion = :estado
    """)
    List<Animal> findByRazaRegionEstado(@Param("raza")   String raza,
                                        @Param("region") String region,
                                        @Param("estado") String estado);

    
    @Query("""
        SELECT AVG(a.edad)
        FROM Animal a
             JOIN a.raza ra
             JOIN a.comuna c
             JOIN c.region r
        WHERE ra.tipo  = :raza
          AND r.nombre = :region
    """)
    Double avgEdadByRazaRegion(@Param("raza")   String raza,
                               @Param("region") String region);

    Animal findByEdad(Integer edad);
}
