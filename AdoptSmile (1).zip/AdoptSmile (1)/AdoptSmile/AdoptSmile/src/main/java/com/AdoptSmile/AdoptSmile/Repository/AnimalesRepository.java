package com.AdoptSmile.AdoptSmile.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.AdoptSmile.AdoptSmile.Model.Animales;
import com.AdoptSmile.AdoptSmile.Model.Usuario;

public interface AnimalesRepository extends JpaRepository<Animales, Long> {
    List<Animales> findByUsuario(Usuario usuario);
    void deleteByUsuario(Usuario usuario);
}
