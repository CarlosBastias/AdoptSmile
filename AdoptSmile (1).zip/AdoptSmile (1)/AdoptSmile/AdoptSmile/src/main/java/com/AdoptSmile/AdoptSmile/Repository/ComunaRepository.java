package com.AdoptSmile.AdoptSmile.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.AdoptSmile.AdoptSmile.Model.Comuna;

@Repository
public interface ComunaRepository extends JpaRepository<Comuna, Long>{

    Comuna findByNombre(String nombre);

    @Query("""
        SELECT c
        FROM Comuna c
             JOIN c.region r
        WHERE r.nombre      = :region
          AND LOWER(c.nombre) LIKE LOWER(CONCAT('%', :nombre,'%'))
    """)
    List<Comuna> findByRegionAndNombreLike(@Param("region") String region,
                                           @Param("nombre") String nombre);
                                           

    @Query("""
        SELECT DISTINCT c
        FROM Comuna c
             JOIN c.region r
             JOIN Animal a ON a.comuna = c
             JOIN a.estado est
        WHERE r.nombre        = :region
          AND est.descripcion = :estado
    """)
    List<Comuna> findConAnimalesPorRegionEstado(@Param("region") String region,
                                                @Param("estado") String estado);

   
    @Query("""
        SELECT COUNT(a)
        FROM Comuna c
             JOIN Animal a   ON a.comuna = c
             JOIN a.raza ra
             JOIN ra.especie e
        WHERE c.nombre = :comuna
          AND e.nombre = :especie
    """)
    long countAnimalesPorComunaEspecie(@Param("comuna")  String comuna,
                                       @Param("especie") String especie);

                          
    @Query("""
        SELECT AVG(a.edad)
        FROM Comuna c
             JOIN Animal a   ON a.comuna = c
             JOIN a.raza ra
             JOIN ra.especie e
        WHERE c.nombre = :comuna
          AND e.nombre = :especie
    """)
    Double avgEdadPorComunaEspecie(@Param("comuna")  String comuna,
                                   @Param("especie") String especie);


}
