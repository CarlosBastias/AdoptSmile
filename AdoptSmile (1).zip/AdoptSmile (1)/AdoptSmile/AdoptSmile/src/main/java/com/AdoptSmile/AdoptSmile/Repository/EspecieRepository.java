package com.AdoptSmile.AdoptSmile.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.AdoptSmile.AdoptSmile.Model.Especie;

@Repository
public interface EspecieRepository extends JpaRepository<Especie, Long>{

    
    @Query("""
        SELECT DISTINCT e
        FROM Especie e
             JOIN Raza ra  ON ra.especie = e
             JOIN Animal a ON a.raza     = ra
             JOIN a.comuna c
             JOIN c.region r
             JOIN a.estado est
        WHERE r.nombre        = :region
          AND est.descripcion = :estado
    """)
    List<Especie> findByRegionEstado(@Param("region") String region,
                                     @Param("estado") String estado);

    
    @Query("""
        SELECT COUNT(a)
        FROM Especie e
             JOIN Raza ra  ON ra.especie = e
             JOIN Animal a ON a.raza     = ra
             JOIN a.comuna c
             JOIN c.region r
        WHERE e.nombre = :especie
          AND r.nombre = :region
    """)
    long countAnimalesPorEspecieRegion(@Param("especie") String especie,
                                       @Param("region")  String region);

    @Query("""
        SELECT DISTINCT u
        FROM Especie e
             JOIN Raza ra  ON ra.especie = e
             JOIN Animal a ON a.raza     = ra
             JOIN Animales an ON an.animal = a
             JOIN an.usuario u
             JOIN a.comuna c
             JOIN c.region r
        WHERE e.nombre = :especie
          AND r.nombre = :region
    """)
    List<com.AdoptSmile.AdoptSmile.Model.Usuario> findUsuariosPorEspecieRegion(
            @Param("especie") String especie,
            @Param("region")  String region);

    
    @Query("""
        SELECT ra, COUNT(a) AS total
        FROM Raza ra
             JOIN ra.especie e
             JOIN Animal a ON a.raza = ra
             JOIN a.comuna c
             JOIN c.region r
        WHERE e.nombre = :especie
          AND r.nombre = :region
        GROUP BY ra
        ORDER BY total DESC
    """)
    List<Object[]> topRazasPorEspecieRegion(@Param("especie") String especie,
                                            @Param("region")  String region);
}
