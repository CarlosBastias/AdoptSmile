package com.AdoptSmile.AdoptSmile.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.AdoptSmile.AdoptSmile.Model.Estado;

@Repository
public interface EstadoRepository extends JpaRepository<Estado, Long>{

    @Query("""
        SELECT DISTINCT est
        FROM Estado est
             JOIN Animal a   ON a.estado = est
             JOIN a.comuna c
             JOIN c.region r
             JOIN a.raza ra
             JOIN ra.especie e
        WHERE r.nombre = :region
          AND e.nombre = :especie
    """)
    List<Estado> findByRegionEspecie(@Param("region") String region,
                                     @Param("especie") String especie);

    @Query("""
        SELECT COUNT(a)
        FROM Estado est
             JOIN Animal a ON a.estado = est
             JOIN a.comuna c
             JOIN c.region r
        WHERE est.descripcion = :estado
          AND r.nombre        = :region
    """)
    long countAnimalesPorEstadoRegion(@Param("estado") String estado,
                                      @Param("region") String region);

    @Query("""
        SELECT DISTINCT u
        FROM Estado est
             JOIN Animal a   ON a.estado = est
             JOIN Animales an ON an.animal = a
             JOIN an.usuario u
             JOIN a.comuna c
             JOIN c.region r
        WHERE est.descripcion = :estado
          AND r.nombre        = :region
    """)
    List<com.AdoptSmile.AdoptSmile.Model.Usuario> findUsuariosPorEstadoRegion(
            @Param("estado") String estado,
            @Param("region") String region);

    @Query("""
        SELECT AVG(a.edad)
        FROM Estado est
             JOIN Animal a   ON a.estado = est
             JOIN a.raza ra
             JOIN ra.especie e
        WHERE est.descripcion = :estado
          AND e.nombre        = :especie
    """)
    Double avgEdadPorEstadoEspecie(@Param("estado")  String estado,
                                   @Param("especie") String especie);
}
