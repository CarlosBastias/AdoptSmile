package com.AdoptSmile.AdoptSmile.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.AdoptSmile.AdoptSmile.Model.Raza;

@Repository
public interface RazaRepository extends JpaRepository<Raza, Long>{

    Raza findByTipo(String tipo);

    @Query("""
        SELECT DISTINCT ra
        FROM Raza ra
             JOIN ra.especie e
             JOIN Animal a   ON a.raza = ra
             JOIN a.comuna c
             JOIN c.region r
        WHERE e.nombre = :especie
          AND r.nombre = :region
    """)
    List<Raza> findByEspecieRegion(@Param("especie") String especie,
                                   @Param("region")  String region);

    @Query("""
        SELECT COUNT(a)
        FROM Raza ra
             JOIN Animal a ON a.raza = ra
             JOIN a.estado est
        WHERE ra.tipo       = :raza
          AND est.descripcion = :estado
    """)
    long countAnimalesPorRazaEstado(@Param("raza")   String raza,
                                    @Param("estado") String estado);

    @Query("""
        SELECT ra, COUNT(a) AS total
        FROM Raza ra
             JOIN Animal a   ON a.raza = ra
             JOIN a.estado est
             JOIN a.comuna c
             JOIN c.region r
        WHERE r.nombre        = :region
          AND est.descripcion = :estado
        GROUP BY ra
        ORDER BY total DESC
    """)
    List<Object[]> topRazasPorRegionEstado(@Param("region") String region,
                                           @Param("estado") String estado);

    @Query("""
        SELECT AVG(a.edad)
        FROM Raza ra
             JOIN Animal a ON a.raza = ra
             JOIN a.comuna c
             JOIN c.region r
        WHERE ra.tipo  = :raza
          AND r.nombre = :region
    """)
    Double avgEdadPorRazaRegion(@Param("raza")   String raza,
                                @Param("region") String region);
}
