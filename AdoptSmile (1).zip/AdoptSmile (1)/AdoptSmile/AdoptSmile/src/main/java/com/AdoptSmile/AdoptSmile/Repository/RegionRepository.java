package com.AdoptSmile.AdoptSmile.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.AdoptSmile.AdoptSmile.Model.Region;

@Repository
public interface RegionRepository extends JpaRepository<Region, Long>{

    Region findByNombre(String nombre);

    @Query("""
        SELECT DISTINCT r
        FROM Region r
             JOIN Comuna c   ON c.region = r
             JOIN Animal a   ON a.comuna = c
             JOIN a.raza ra
             JOIN ra.especie e
             JOIN a.estado est
        WHERE e.nombre        = :especie
          AND est.descripcion = :estado
    """)
    List<Region> findByEspecieYEstado(@Param("especie") String especie,
                                      @Param("estado")  String estado);

    @Query("""
        SELECT COUNT(a)
        FROM Region r
             JOIN Comuna c ON c.region = r
             JOIN Animal a ON a.comuna = c
             JOIN a.raza ra
             JOIN ra.especie e
        WHERE r.nombre = :region
          AND e.nombre = :especie
    """)
    long countAnimalesPorRegionEspecie(@Param("region")  String region,
                                       @Param("especie") String especie);

    @Query("""
        SELECT AVG(a.edad)
        FROM Region r
             JOIN Comuna c ON c.region = r
             JOIN Animal a ON a.comuna = c
             JOIN a.raza ra
             JOIN ra.especie e
        WHERE r.nombre = :region
          AND e.nombre = :especie
    """)
    Double avgEdadPorRegionEspecie(@Param("region")  String region,
                                   @Param("especie") String especie);

    @Query("""
        SELECT DISTINCT u
        FROM Region r
             JOIN Comuna c   ON c.region = r
             JOIN Animal a   ON a.comuna = c
             JOIN a.estado est
             JOIN Animales an ON an.animal = a
             JOIN an.usuario u
        WHERE r.nombre        = :region
          AND est.descripcion = :estado
    """)
    List<com.AdoptSmile.AdoptSmile.Model.Usuario> findUsuariosPorRegionEstado(
            @Param("region") String region,
            @Param("estado") String estado);
}
