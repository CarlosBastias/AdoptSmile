package com.AdoptSmile.AdoptSmile.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.AdoptSmile.AdoptSmile.Model.Usuario;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    Usuario findByNombre(String nombre);

    @Query("""
        SELECT DISTINCT u
        FROM Usuario u
             JOIN Animales an ON an.usuario = u
             JOIN an.animal a
             JOIN a.estado est
             JOIN a.comuna c
             JOIN c.region r
        WHERE r.nombre        = :region
          AND est.descripcion = :estado
    """)
    List<Usuario> findByRegionYEstado(@Param("region") String region,
                                      @Param("estado") String estado);

    @Query("""
        SELECT COUNT(an)
        FROM Animales an
             JOIN an.animal a
             JOIN a.estado est
        WHERE an.usuario.id_usuario = :usuarioId
          AND est.descripcion       = :estado
    """)
    long countAnimalesUsuarioEstado(@Param("usuarioId") Integer usuarioId,
                                    @Param("estado")    String  estado);

    @Query("""
        SELECT DISTINCT u
        FROM Usuario u
             JOIN Animales an ON an.usuario = u
             JOIN an.animal  a
             JOIN a.raza     ra
             JOIN ra.especie e
             JOIN a.comuna   c
             JOIN c.region   r
             JOIN a.estado   est
        WHERE e.nombre        = :especie
          AND r.nombre        = :region
          AND est.descripcion = :estado
    """)
    List<Usuario> findPorEspecieRegionEstado(@Param("especie") String especie,
                                             @Param("region")  String region,
                                             @Param("estado")  String estado);

    @Query("""
        SELECT AVG(a.edad)
        FROM Animales an
             JOIN an.animal a
             JOIN a.estado est
        WHERE an.usuario.id_usuario = :usuarioId
          AND est.descripcion       = :estado
    """)
    Double avgEdadAnimalesUsuarioEstado(@Param("usuarioId") Integer usuarioId,
                                        @Param("estado")    String  estado);
}
