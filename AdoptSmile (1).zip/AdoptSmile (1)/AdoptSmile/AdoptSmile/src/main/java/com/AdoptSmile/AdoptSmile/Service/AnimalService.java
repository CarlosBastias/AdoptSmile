package com.AdoptSmile.AdoptSmile.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AdoptSmile.AdoptSmile.Model.Animal;
import com.AdoptSmile.AdoptSmile.Repository.AnimalRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class AnimalService {

    @Autowired
    private AnimalRepository animalRepository;

    public Animal findById(Long id) {
        return animalRepository.findById(id).orElse(null);
    }

    public List<Animal> findAll() {
        return animalRepository.findAll();
    }

    public Animal save(Animal animal) {
        return animalRepository.save(animal);
    }

    public Animal update(Long id, Animal animal) {
        Animal animalToUpdate = animalRepository.findById(id).orElse(null);
        if (animalToUpdate != null) {
            animalToUpdate.setEdad(animal.getEdad());
            animalToUpdate.setEspecificaciones(animal.getEspecificaciones());
            animalToUpdate.setNecesidades(animal.getNecesidades());
            animalToUpdate.setTamaño(animal.getTamaño());
            return animalRepository.save(animalToUpdate);
        } else {
            return null;
        }
    }

    public void deleteById(Long id) {
    Animal animal = animalRepository.findById(id).orElse(null);

    if (animal != null) {
        animalRepository.deleteById(id);
    } else {
        throw new RuntimeException("Animal no encontrado con id: " + id);
    }
}

    public Animal patchAnimal(Long id, Animal animal) {
        Animal animalToPatch = findById(id);
        if (animalToPatch != null) {
            if (animal.getEdad() != null){ 
                animalToPatch.setEdad(animal.getEdad());
            }
            if (animal.getEspecificaciones() != null){
                animalToPatch.setEspecificaciones(animal.getEspecificaciones());
            }
            if (animal.getNecesidades() != null){
                animalToPatch.setNecesidades(animal.getNecesidades());
            }
            if (animal.getTamaño() != null){
                animalToPatch.setTamaño(animal.getTamaño());
            }
            return save(animalToPatch);
        } 
        return null;
    }

    

    public Animal buscarPorEdad(Integer edad) {
        return animalRepository.findByEdad(edad);
    }

    public List<Animal> getByRegionEspecieEstado(String region, String especie, String estado) {
        return animalRepository.findByRegionEspecieEstado(region, especie, estado);
    }

    public long countByEspecieRegionEdad(String especie, Integer regionId, Integer minEdad, Integer maxEdad) {
        return animalRepository.countByEspecieRegionEdad(especie, regionId, minEdad, maxEdad);
    }

    public List<Animal> getByRazaRegionEstado(String raza, String region, String estado) {
        return animalRepository.findByRazaRegionEstado(raza, region, estado);
    }

    public Double averageEdadByRazaRegion(String raza, String region) {
        return animalRepository.avgEdadByRazaRegion(raza, region);
    } 
}
