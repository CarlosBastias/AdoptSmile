package com.AdoptSmile.AdoptSmile.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AdoptSmile.AdoptSmile.Model.Comuna;
import com.AdoptSmile.AdoptSmile.Repository.ComunaRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ComunaService {

    @Autowired
    private ComunaRepository comunaRepository;

    public Comuna findById(Long id) {
        return comunaRepository.findById(id).orElse(null);
    }

    public List<Comuna> findAll() {
        return comunaRepository.findAll();
    }

    public Comuna save(Comuna comuna) {
        return comunaRepository.save(comuna);
    }

    public Comuna update(Long id, Comuna comuna) {
        Comuna comunaToUpdate = comunaRepository.findById(id).orElse(null);
        if (comunaToUpdate != null) {
            comunaToUpdate.setNombre(comuna.getNombre());
            return comunaRepository.save(comunaToUpdate);
        } else {
            return null;
        }
    }

    public void deleteById(Long id) {
        comunaRepository.deleteById(id);
    }

    public Comuna patchComuna(Long id, Comuna comuna) {
        Comuna comunaToPatch = findById(id);
        if (comunaToPatch != null) {
            if (comuna.getNombre() != null) {
                comunaToPatch.setNombre(comuna.getNombre());
            }
            return comunaRepository.save(comunaToPatch);
        } 
        return null;
        
    }

    public Comuna buscarPorNombre(String nombre) {
        return comunaRepository.findByNombre(nombre);
    }
    public List<Comuna> buscarPorRegionYNombreLike(String region, String nombre) {
        return comunaRepository.findByRegionAndNombreLike(region, nombre);
    }

    public List<Comuna> buscarConAnimalesPorRegionEstado(String region, String estado) {
        return comunaRepository.findConAnimalesPorRegionEstado(region, estado);
    }

    public long contarAnimalesPorComunaEspecie(String comuna, String especie) {
        return comunaRepository.countAnimalesPorComunaEspecie(comuna, especie);
    }

    public double promedioEdadAnimalesPorComunaEspecie(String comuna, String especie) {
        return comunaRepository.avgEdadPorComunaEspecie(comuna, especie);
    }
}
