package com.AdoptSmile.AdoptSmile.Service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.AdoptSmile.AdoptSmile.Model.Usuario;
import com.AdoptSmile.AdoptSmile.Repository.AnimalesRepository;
import com.AdoptSmile.AdoptSmile.Repository.UsuarioRepository;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private AnimalesRepository animalesRepository;

    public Usuario findById(Long id) {
        return usuarioRepository.findById(id).orElse(null);
    }

    public List<Usuario> findAll() {
        return usuarioRepository.findAll();
    }

    public Usuario save(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    public Usuario update(Long id, Usuario usuario) {
        Usuario usuarioToUpdate = usuarioRepository.findById(id).orElse(null);
        if (usuarioToUpdate != null) {
            usuarioToUpdate.setNombre(usuario.getNombre());
            usuarioToUpdate.setCorreo(usuario.getCorreo());
            return usuarioRepository.save(usuarioToUpdate);
        } else {
            return null;
        }
    }

public void deleteUsuarioById(Long id) {
        Usuario usuario = usuarioRepository.findById(id.longValue())
            .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        animalesRepository.deleteByUsuario(usuario);
        usuarioRepository.delete(usuario);
    }

    public Usuario patchUsuario(Long id, Usuario usuario) {
        Usuario usuarioToPatch = usuarioRepository.findById(id).orElse(null);
        if (usuarioToPatch != null) {
            if (usuario.getNombre() != null) {
                usuarioToPatch.setNombre(usuario.getNombre());
            }
            if (usuario.getCorreo() != null) {
                usuarioToPatch.setCorreo(usuario.getCorreo());
            }
            return usuarioRepository.save(usuarioToPatch);
        } else {
            return null;
        }
    }

    public Usuario findByNombre(String nombre) {
    return usuarioRepository.findByNombre(nombre);
    }

    public List<Usuario> findByRegionYEstado(String region, String estado) {
        return usuarioRepository.findByRegionYEstado(region, estado);
    }

    public long countAnimalesUsuarioEstado(Integer usuarioId, String estado) {
        return usuarioRepository.countAnimalesUsuarioEstado(usuarioId, estado);
    }

    public Double avgEdadAnimalesUsuarioEstado(Integer usuarioId, String estado) {
        return usuarioRepository.avgEdadAnimalesUsuarioEstado(usuarioId, estado);
    }

    public List<Usuario> findPorEspecieRegionEstado(String especie, String region, String estado) {
        return usuarioRepository.findPorEspecieRegionEstado(especie, region, estado);
    }
    
}


