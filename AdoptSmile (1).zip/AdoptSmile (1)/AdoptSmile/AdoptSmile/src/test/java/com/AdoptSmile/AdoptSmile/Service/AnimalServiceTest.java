package com.AdoptSmile.AdoptSmile.Service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.AdoptSmile.AdoptSmile.Repository.AnimalRepository;


import com.AdoptSmile.AdoptSmile.Model.Animal;
import com.AdoptSmile.AdoptSmile.Model.Comuna;
import com.AdoptSmile.AdoptSmile.Model.Estado;
import com.AdoptSmile.AdoptSmile.Model.Raza;


@SpringBootTest

public class AnimalServiceTest {

    @Autowired
    private AnimalService animalService;

    @MockBean
    private AnimalRepository animalRepository;

    private Animal createAnimal() {
        return new Animal(
            1,                
            3,                
            "Mediano",       
            "Juguetón",       
            "Sin alergias",   
            new Estado(),     
            new Comuna(),    
            new Raza()        
        );
    }

 
    @Test
    public void testFindAll() {
        when(animalRepository.findAll()).thenReturn(List.of(createAnimal()));
        List<Animal> animales = animalService.findAll();
        assertNotNull(animales);
        assertEquals(1, animales.size());
    }

    @Test
    public void testFindById() {
        when(animalRepository.findById(1L)).thenReturn(Optional.of(createAnimal()));
        Animal animal = animalService.findById(1L);
        assertNotNull(animal);
        assertEquals("Mediano", animal.getTamaño());
    }

    @Test
    public void testSave() {
        Animal animal = createAnimal();
        when(animalRepository.save(animal)).thenReturn(animal);
        Animal saved = animalService.save(animal);
        assertNotNull(saved);
        assertEquals("Mediano", saved.getTamaño());
    }

    @Test
    public void testPatchAnimal() {
        Animal existing = createAnimal();
        Animal patchData = new Animal();           // solo campos a modificar
        patchData.setTamaño("Grande");

        when(animalRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(animalRepository.save(any(Animal.class))).thenReturn(existing);

        Animal patched = animalService.patchAnimal(1L, patchData);
        assertNotNull(patched);
        assertEquals("Grande", patched.getTamaño());
    }

    @Test
    public void testDeleteById() {
        doNothing().when(animalRepository).deleteById(1L);
        animalService.deleteById(1L);
        verify(animalRepository, times(1)).deleteById(1L);
    }
}
