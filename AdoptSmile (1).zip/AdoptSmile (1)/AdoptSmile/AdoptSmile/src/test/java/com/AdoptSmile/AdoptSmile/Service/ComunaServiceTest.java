package com.AdoptSmile.AdoptSmile.Service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.AdoptSmile.AdoptSmile.Model.Comuna;
import com.AdoptSmile.AdoptSmile.Model.Region;
import com.AdoptSmile.AdoptSmile.Repository.ComunaRepository;

@SpringBootTest
public class ComunaServiceTest {

    @Autowired
    private ComunaService comunaService;

    @MockBean
    private ComunaRepository comunaRepository;

    private Comuna createComuna() {
        return new Comuna(1, "Santiago", 
        new Region());
    }

    @Test
    public void testFindAll() {
        when(comunaRepository.findAll()).thenReturn(List.of(createComuna()));
        assertEquals(1, comunaService.findAll().size());
    }

    @Test
    public void testFindById() {
        when(comunaRepository.findById(1L)).thenReturn(Optional.of(createComuna()));
        assertEquals("Santiago", comunaService.findById(1L).getNombre());
    }

    @Test
    public void testSave() {
        Comuna com = createComuna();
        when(comunaRepository.save(com)).thenReturn(com);
        assertEquals("Santiago", comunaService.save(com).getNombre());
    }

    @Test
    public void testPatchComuna() {
        Comuna existing = createComuna();
        Comuna patch = new Comuna();
        patch.setNombre("Providencia");

        when(comunaRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(comunaRepository.save(any(Comuna.class))).thenReturn(existing);

        Comuna upd = comunaService.patchComuna(1L, patch);
        assertEquals("Providencia", upd.getNombre());
    }

    @Test
    public void testDeleteById() {
        doNothing().when(comunaRepository).deleteById(1L);
        comunaService.deleteById(1L);
        verify(comunaRepository).deleteById(1L);
    }
}
