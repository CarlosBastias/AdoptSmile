package com.AdoptSmile.AdoptSmile.Service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.AdoptSmile.AdoptSmile.Model.Especie;
import com.AdoptSmile.AdoptSmile.Repository.EspecieRepository;

@SpringBootTest
public class EspecieServiceTest {

    @Autowired
    private EspecieService especieService;

    @MockBean
    private EspecieRepository especieRepository;

    private Especie createEspecie() {
        return new Especie(1, "Canino");
    }

    @Test
    public void testFindAll() {
        when(especieRepository.findAll()).thenReturn(List.of(createEspecie()));
        List<Especie> list = especieService.findAll();
        assertNotNull(list);
        assertEquals(1, list.size());
    }

    @Test
    public void testFindById() {
        when(especieRepository.findById(1L)).thenReturn(Optional.of(createEspecie()));
        Especie esp = especieService.findById(1L);
        assertNotNull(esp);
        assertEquals("Canino", esp.getNombre());
    }

    @Test
    public void testSave() {
        Especie esp = createEspecie();
        when(especieRepository.save(esp)).thenReturn(esp);
        Especie saved = especieService.save(esp);
        assertEquals("Canino", saved.getNombre());
    }

    @Test
    public void testPatchEspecie() {
        Especie existing = createEspecie();
        Especie patch = new Especie();
        patch.setNombre("Felino");

        when(especieRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(especieRepository.save(any(Especie.class))).thenReturn(existing);

        Especie updated = especieService.patchEspecie(1L, patch);
        assertEquals("Felino", updated.getNombre());
    }

    @Test
    public void testDeleteById() {
        doNothing().when(especieRepository).deleteById(1L);
        especieService.deleteById(1L);
        verify(especieRepository).deleteById(1L);
    }
}
