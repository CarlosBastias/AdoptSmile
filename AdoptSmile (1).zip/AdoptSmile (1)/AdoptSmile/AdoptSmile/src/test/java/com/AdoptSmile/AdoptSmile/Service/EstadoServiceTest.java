package com.AdoptSmile.AdoptSmile.Service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.AdoptSmile.AdoptSmile.Model.Estado;
import com.AdoptSmile.AdoptSmile.Repository.EstadoRepository;

@SpringBootTest
public class EstadoServiceTest {

    @Autowired
    private EstadoService estadoService;

    @MockBean
    private EstadoRepository estadoRepository;

    private Estado createEstado() {
        return new Estado(1, "Disponible");
    }

    @Test
    public void testFindAll() {
        when(estadoRepository.findAll()).thenReturn(List.of(createEstado()));
        assertFalse(estadoService.findAll().isEmpty());
    }

    @Test
    public void testFindById() {
        when(estadoRepository.findById(1L)).thenReturn(Optional.of(createEstado()));
        assertEquals("Disponible", estadoService.findById(1L).getDescripcion());
    }

    @Test
    public void testSave() {
        Estado est = createEstado();
        when(estadoRepository.save(est)).thenReturn(est);
        assertEquals("Disponible", estadoService.save(est).getDescripcion());
    }

    @Test
    public void testPatchEstado() {
        Estado existing = createEstado();
        Estado patch = new Estado();
        patch.setDescripcion("Adoptado");

        when(estadoRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(estadoRepository.save(any(Estado.class))).thenReturn(existing);

        Estado upd = estadoService.patchEstado(1L, patch);
        assertEquals("Adoptado", upd.getDescripcion());
    }

    @Test
    public void testDeleteById() {
        doNothing().when(estadoRepository).deleteById(1L);
        estadoService.deleteById(1L);
        verify(estadoRepository).deleteById(1L);
    }
}
