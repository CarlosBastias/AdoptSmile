package com.AdoptSmile.AdoptSmile.Service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.AdoptSmile.AdoptSmile.Model.Especie;
import com.AdoptSmile.AdoptSmile.Model.Raza;
import com.AdoptSmile.AdoptSmile.Repository.RazaRepository;

@SpringBootTest
public class RazaServiceTest {

    @Autowired
    private RazaService razaService;

    @MockBean
    private RazaRepository razaRepository;

    private Raza createRaza() {
        return new Raza(1, "Labrador", 
        new Especie());
    }

    @Test
    public void testFindAll() {
        when(razaRepository.findAll()).thenReturn(List.of(createRaza()));
        assertEquals(1, razaService.findAll().size());
    }

    @Test
    public void testFindById() {
        when(razaRepository.findById(1L)).thenReturn(Optional.of(createRaza()));
        assertEquals("Labrador", razaService.findById(1L).getTipo());
    }

    @Test
    public void testSave() {
        Raza rz = createRaza();
        when(razaRepository.save(rz)).thenReturn(rz);
        assertEquals("Labrador", razaService.save(rz).getTipo());
    }

    @Test
    public void testPatchRaza() {
        Raza existing = createRaza();
        Raza patch = new Raza();
        patch.setTipo("Pastor Alemán");

        when(razaRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(razaRepository.save(any(Raza.class))).thenReturn(existing);

        Raza upd = razaService.patchRaza(1L, patch);
        assertEquals("Pastor Alemán", upd.getTipo());
    }

    @Test
    public void testDeleteById() {
        doNothing().when(razaRepository).deleteById(1L);
        razaService.deleteById(1L);
        verify(razaRepository).deleteById(1L);
    }
}

