package com.AdoptSmile.AdoptSmile.Service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.AdoptSmile.AdoptSmile.Model.Region;
import com.AdoptSmile.AdoptSmile.Repository.RegionRepository;

@SpringBootTest
public class RegionServiceTest {

    @Autowired
    private RegionService regionService;

    @MockBean
    private RegionRepository regionRepository;

    private Region createRegion() {
        return new Region(1, "Metropolitana");
    }

    @Test
    public void testFindAll() {
        when(regionRepository.findAll()).thenReturn(List.of(createRegion()));
        assertEquals(1, regionService.findAll().size());
    }

    @Test
    public void testFindById() {
        when(regionRepository.findById(1L)).thenReturn(Optional.of(createRegion()));
        assertEquals("Metropolitana", regionService.findById(1L).getNombre());
    }

    @Test
    public void testSave() {
        Region reg = createRegion();
        when(regionRepository.save(reg)).thenReturn(reg);
        assertEquals("Metropolitana", regionService.save(reg).getNombre());
    }

    @Test
    public void testPatchRegion() {
        Region existing = createRegion();
        Region patch = new Region();
        patch.setNombre("Valparaíso");

        when(regionRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(regionRepository.save(any(Region.class))).thenReturn(existing);

        Region upd = regionService.patchRegion(1L, patch);
        assertEquals("Valparaíso", upd.getNombre());
    }

    @Test
    public void testDeleteById() {
        doNothing().when(regionRepository).deleteById(1L);
        regionService.deleteById(1L);
        verify(regionRepository).deleteById(1L);
    }
}
