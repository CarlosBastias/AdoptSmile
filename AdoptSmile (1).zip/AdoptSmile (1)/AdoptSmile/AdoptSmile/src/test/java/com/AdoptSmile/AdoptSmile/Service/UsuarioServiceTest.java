package com.AdoptSmile.AdoptSmile.Service;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.AdoptSmile.AdoptSmile.Model.Usuario;
import com.AdoptSmile.AdoptSmile.Repository.UsuarioRepository;
import com.AdoptSmile.AdoptSmile.Repository.AnimalesRepository;

@SpringBootTest
public class UsuarioServiceTest {

    @Autowired
    private UsuarioService usuarioService;

    @MockBean
    private UsuarioRepository usuarioRepository;

    @MockBean
    private AnimalesRepository animalesRepository;

    private Usuario createUsuario() {
        return new Usuario(
            1,
            "Carlos Pérez",
            "carlos@email.com",
            "contrasena123",
            "987654321",
            "Av. Siempre Viva 123"
        );
    }

    @Test
    public void testFindAll() {
        when(usuarioRepository.findAll()).thenReturn(List.of(createUsuario()));
        List<Usuario> usuarios = usuarioService.findAll();
        assertNotNull(usuarios);
        assertEquals(1, usuarios.size());
    }

    @Test
    public void testFindById() {
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(createUsuario()));
        Usuario usuario = usuarioService.findById(1L);
        assertNotNull(usuario);
        assertEquals("Carlos Pérez", usuario.getNombre());
    }

    @Test
    public void testSave() {
        Usuario usuario = createUsuario();
        when(usuarioRepository.save(usuario)).thenReturn(usuario);
        Usuario savedUsuario = usuarioService.save(usuario);
        assertNotNull(savedUsuario);
        assertEquals("Carlos Pérez", savedUsuario.getNombre());
    }

    @Test
    public void testPatchUsuario() {
        Usuario existingUsuario = createUsuario();
        Usuario patchData = new Usuario();
        patchData.setNombre("Carlos Actualizado");

        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(existingUsuario));
        when(usuarioRepository.save(any(Usuario.class))).thenReturn(existingUsuario);

        Usuario patchedUsuario = usuarioService.patchUsuario(1L, patchData);
        assertNotNull(patchedUsuario);
        assertEquals("Carlos Actualizado", patchedUsuario.getNombre());
    }

    @Test
    public void testDeleteUsuarioById() {
        Usuario usuario = createUsuario();

        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuario));

        doNothing().when(animalesRepository).deleteByUsuario(usuario);
        doNothing().when(usuarioRepository).delete(usuario);

        usuarioService.deleteUsuarioById(1L);

        verify(animalesRepository, times(1)).deleteByUsuario(usuario);
        verify(usuarioRepository, times(1)).delete(usuario);
    }
}
